package com.journal.test.repository;

public class UserRepository {
  
}
