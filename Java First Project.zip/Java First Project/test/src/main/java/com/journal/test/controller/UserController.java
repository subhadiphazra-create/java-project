package com.journal.test.controller;

import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.journal.test.entity.User;
import com.journal.test.services.UserService;

@RestController
@RequestMapping("/user")
public class UserController {

  @Autowired
  private UserService userService;


  @GetMapping
  public List<User> getAllUsers(){
    return userService.getAll();
  }

  @PostMapping
  public void createUser(@RequestBody User user){
    userService.saveEntry(user);
  }

  @PutMapping("{id}")
  public ResponseEntity<?> updateUserEntry(@RequestBody User user,@PathVariable ObjectId id){
    User userInDb =  userService.fndByUserName(user.getUserName());
    if(userInDb != null ){
      userInDb.setUserName(user.getUserName());
      userInDb.setPassword(user.getPassword());
      userService.saveEntry(userInDb);
    }
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }
}
